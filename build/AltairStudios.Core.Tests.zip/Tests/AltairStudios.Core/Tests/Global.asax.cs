﻿using System;
using AltairStudios.Core.Mvc;


namespace AltairStudios.Core.Tests.Web {
	public class MvcApplication : AltairStudios.Core.Mvc.MvcApplication {
	}
}