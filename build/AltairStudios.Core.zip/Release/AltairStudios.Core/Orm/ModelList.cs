using System;
using System.Text;


namespace AltairStudios.Core.Orm {
	/// <summary>
	/// Model list.
	/// </summary>
	public class ModelList<T> : AltairStudios.Core.Mvc.ModelList<T> {
	}
}