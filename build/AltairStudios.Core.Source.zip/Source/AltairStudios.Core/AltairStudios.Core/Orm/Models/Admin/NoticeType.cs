using System;


namespace AltairStudios.Core.Orm.Models.Admin {
	/// <summary>
	/// Notice type.
	/// </summary>
	public enum NoticeType {
		/// <summary>
		/// Constant information.
		/// </summary>
		Information = 1
	}
}